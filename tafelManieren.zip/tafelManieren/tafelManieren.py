# Tafelmanieren


# Opdracht 1

for i in range(1, 11):
    print(f"{i} x 4 = " + str(i * 4))


# Opdracht 2

for o in range(30, 0, -1):
    print(str(o * 1) + ' seconden.')


# Opdracht 3

for p in range(1, 13):
    print(str(p * 1) + 'AM')
for p in range(1, 13):
    print(str(p * 1) + 'PM')


# Opdracht 4

for u in range(20, 51):
    print(str(u * 1))